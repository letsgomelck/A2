/* Class:			InvalidRefreshments
 * Description:		represents an issue that occurs when a Refreshment problem is found
 * Author:          HuiyuWang - s3737937
 */
public class InvalidRefreshments extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	

}
