/* Class:			InvalidRefreshments
 * Description:		represents an issue that occurs when a Refreshment problem is found
 * Author:          LiangyuNie - s3716113
 */
public class InvalidRefreshments extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	

}
