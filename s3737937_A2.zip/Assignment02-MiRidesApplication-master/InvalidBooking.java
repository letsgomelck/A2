/*
 * Class:			InvalidBooking
 * Description:		represents an issue that occurs when a booking problem is found
 * Author:          LiangyuNie - s3716113
 */
public class InvalidBooking extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	
}
